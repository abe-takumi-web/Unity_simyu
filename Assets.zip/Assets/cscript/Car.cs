using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Car : MonoBehaviour
{
    public List<AxleInfo> axleInfos;
    public float maxMotorTorque;
    public float maxSteeringAngle;

    public void FixedUpdate()
    {
        float motor = maxMotorTorque * Input.GetAxis("Vertical");
        float steering = maxSteeringAngle * Input.GetAxis("Horizontal");
        foreach (AxleInfo axleInfo in axleInfos)
        {
            Transform leftTransform = axleInfo.leftobj.transform;
            Transform rightTransform = axleInfo.rightobj.transform;
            if (axleInfo.motor)
            {
                axleInfo.leftWheel.motorTorque = motor;
                axleInfo.rightWheel.motorTorque = motor;
                leftTransform.Rotate(motor, 0, 0);
                rightTransform.Rotate(motor, 0, 0);
                if (Input.GetAxis("Horizontal") != 0)
                {
                    axleInfo.leftWheel.motorTorque = steering;
                    axleInfo.rightWheel.motorTorque = -steering;
                    leftTransform.Rotate(steering, 0, 0);
                    rightTransform.Rotate(-steering, 0, 0);
                    Debug.Log("curb");
                   
                }
            }
        }
    }
}
[System.Serializable]
public class AxleInfo
{
    public WheelCollider leftWheel;
    public WheelCollider rightWheel;
    public bool motor; 
    public bool steering;
    public BoxCollider rightobj;
    public BoxCollider leftobj;
}