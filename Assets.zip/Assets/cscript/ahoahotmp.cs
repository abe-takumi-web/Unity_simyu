using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ahoahotmp : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        SaveLevel(23);
        var resurt = TestMassage(1, 2);
        Debug.Log(resurt);
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void SaveLevel(int level)
    {
        Debug.Log(level);
    }
    public string TestMassage(int value1,int value2)
    {
        return string.Format("{0:N}��{1:C}���n���ꂽ��", value1, value2);
    }

}
